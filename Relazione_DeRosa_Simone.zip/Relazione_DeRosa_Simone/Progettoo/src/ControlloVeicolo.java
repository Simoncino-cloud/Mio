	
public class ControlloVeicolo {
    public void selezionaVeicolo(String tipoVeicolo) {
        System.out.println("Il veicolo scelto è: " + tipoVeicolo);
    }
}