//Infine il client
public class Client{
	public static void main(String[] args) {
		//Creiamo i vari receiver
		Manubrio manubrio = new Manubrio();
		Motore motore = new Motore(); 
		Marce marce = new Marce();
		ControlloVeicolo veicolo = new ControlloVeicolo();
		Luce luce = new Luce();
		
		//Poi i comandi
		Radiocomando sterzaSinistra = new SterzaSinistraComando(manubrio);
		Radiocomando sterzaDestra = new SterzaDestraComando(manubrio);
		Radiocomando acceleratore = new ComandoAccelleratore(motore);
		Radiocomando primaMarcia = new PrimaMarcia(marce);
		Radiocomando retromarcia = new Retromarcia(marce);
		Radiocomando freno = new ComandoFreno(motore);
		Radiocomando scegliAuto = new SelezioneVeicolo(veicolo, "Auto");
		Radiocomando scegliMoto = new SelezioneVeicolo(veicolo, "Moto");
		Radiocomando scegliCamion = new SelezioneVeicolo(veicolo, "Camion");
		Radiocomando luceSinistra = new LampadinaSinistra(luce);
		Radiocomando luceDestra = new LampadinaDestra(luce);
		
		
		//Creiamo l'invoker al radiocomando
		RemoteControl remoteControl = new RemoteControl();

		
		 // Esecuzione dei comandi
        remoteControl.setComando(sterzaSinistra);
        remoteControl.sterzaSinistra(); // Manubrio gira a sinistra

        remoteControl.setComando(sterzaDestra);
        remoteControl.sterzaDestra(); // Manubrio gira a destra

        remoteControl.setComando(acceleratore);
        remoteControl.accellera(); // Il veicolo accelera

        remoteControl.setComando(freno);
        remoteControl.frena(); // Il veicolo si ferma

        remoteControl.setComando(scegliAuto);
        remoteControl.selezionaVeicolo(); //E' selezionata l'auto

        remoteControl.setComando(scegliMoto);
        remoteControl.selezionaVeicolo(); //E' stata selezionata la moto

        remoteControl.setComando(scegliCamion);
        remoteControl.selezionaVeicolo(); //E' stato selezionato il camion

        remoteControl.setComando(primaMarcia);
        remoteControl.vaiAvanti(); // Il veicolo parte in prima marcia

        remoteControl.setComando(retromarcia);
        remoteControl.vaIndietro(); // Il veicolo va in retromarcia
        
        remoteControl.setComando(luceSinistra);
        remoteControl.accendiSinistra();	//Accesa luce sinistra
        
        remoteControl.setComando(luceDestra);
        remoteControl.accendiDestra();	//Accesa luce destra
    }
}











