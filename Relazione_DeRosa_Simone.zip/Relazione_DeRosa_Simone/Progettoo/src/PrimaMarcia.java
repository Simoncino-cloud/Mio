//Ora gestiamo le marce crendone una che ci permette di partire e andare avanti 
//e l'altra per la retromarcia
public class PrimaMarcia implements Radiocomando{
	private Marce marce;
	
	public PrimaMarcia (Marce marce) {
		this.marce = marce;
	}
	
	@Override
	public void esegui() {
		marce.vaiAvanti();
}
}