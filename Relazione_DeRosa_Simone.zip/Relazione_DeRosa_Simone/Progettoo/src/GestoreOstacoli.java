// Client: gestisce l'interazione con l'utente

import java.util.Scanner;

public class GestoreOstacoli {
    public static void main(String[] args) {
        Telecamera telecamera = new Telecamera();
        ArchivioOstacoli archivio = new ArchivioOstacoli();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Telecamera ha rilevato un ostacolo! Inserisci un ID univoco (es. 'palo', 'muro', 'albero'):");
            String idOstacolo = scanner.nextLine();

            // Verifica se l'ostacolo è già stato registrato
            OstacoloMemento ostacoloEsistente = archivio.recuperaOstacolo(idOstacolo);

            if (ostacoloEsistente != null) {
                System.out.println("Ostacolo riconosciuto: " + ostacoloEsistente.getNomeOstacolo());
            } else {
                System.out.println("Nuovo ostacolo rilevato. Inserisci un nome per identificarlo:");
                String nome = scanner.nextLine();

                OstacoloMemento nuovoOstacolo = telecamera.salvaOstacolo(nome);
                archivio.aggiungiOstacolo(idOstacolo, nuovoOstacolo);

                System.out.println("Ostacolo salvato con il nome: " + nome);
            }

            System.out.println("Continuare a rilevare ostacoli? (s/n)");
            String risposta = scanner.nextLine();
            if (risposta.equalsIgnoreCase("n")) {
                break;
            }
        }

        scanner.close();
        System.out.println("Sistema di riconoscimento ostacoli terminato.");
    }
}
