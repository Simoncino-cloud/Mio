public class LuceDestra {
	    public void accendi() {
	        System.out.println("Luce destra accesa");
	    }

	    public void spegni() {
	        System.out.println("Luce destra spenta");
	    }
	}
	