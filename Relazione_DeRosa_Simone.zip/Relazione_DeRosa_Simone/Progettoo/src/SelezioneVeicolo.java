
//Scelta del tipo di veicolo che si vuole guidare
public class SelezioneVeicolo implements Radiocomando{
	private ControlloVeicolo veicolo;
	private String TipoVeicolo;
	
	public SelezioneVeicolo (ControlloVeicolo veicolo, String TipoVeicolo) {
		this.veicolo = veicolo;
		this.TipoVeicolo = TipoVeicolo;
	}
	
	@Override
	public void esegui() {
		veicolo.SelezioneVeicolo(TipoVeicolo);
	}
	
}