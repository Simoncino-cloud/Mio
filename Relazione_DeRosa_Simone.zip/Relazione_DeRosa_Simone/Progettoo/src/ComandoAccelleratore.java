
//Da qui andiamo a Gestiamo l'acceleratore e il freno
public class ComandoAccelleratore implements Radiocomando{
	private Motore motore;
	
	public ComandoAccelleratore(Motore motore){
		this.motore = motore;
	}
	@Override
	public void esegui() {
		motore.accellera();
}
}