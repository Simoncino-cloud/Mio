//Qui per gestire il Radiocomando utilizzeremo il patter Command
//In cui abbiamo il command
public interface Radiocomando {
	void esegui();
}


