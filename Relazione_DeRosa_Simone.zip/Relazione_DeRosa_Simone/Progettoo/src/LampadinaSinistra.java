
public class LampadinaSinistra implements Radiocomando{
	private Luce luce;
	
	public LampadinaSinistra(Luce luce) {
		this.luce = luce;				
	}
	
	@Override
	public void esegui() {
		luce.accendiSinistra();
	}
	
}
