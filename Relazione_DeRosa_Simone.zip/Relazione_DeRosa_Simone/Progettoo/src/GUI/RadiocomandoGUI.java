import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class RadiocomandoGUI extends JFrame implements KeyListener, MouseListener {
    private boolean gameStarted = false;
    private boolean gameOver = false;
    private Rectangle startButton = new Rectangle(300, 250, 200, 50);
    private Rectangle exitButton = new Rectangle(300, 320, 200, 50);
    private Rectangle tryAgainButton = new Rectangle(300, 300, 200, 50);
    private int carX = 350;
    private int carY = 500;
    private int carSpeed = 20;
    private int[] obstaclesX = new int[5];
    private int[] obstaclesY = new int[5];
    private int obstacleSpeed = 4;
    private GamePanel gamePanel;
    private Timer gameTimer;
    private String selectedVehicle = "Auto"; // Default vehicle

    public RadiocomandoGUI() {
        setTitle("Veicolo Radiocomandato");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        addKeyListener(this);
        addMouseListener(this);
        setFocusable(true);

        gamePanel = new GamePanel();
        add(gamePanel);
    }

    private void startGame() {
        gameStarted = true;
        gameOver = false;
        carX = 350;
        carY = 500;
        obstacleSpeed = 4;
        initializeObstacles();
        
        if (gameTimer != null) {
            gameTimer.stop();
        }

        gameTimer = new Timer(16, e -> updateGame()); // 60 FPS
        gameTimer.start();
        gamePanel.repaint();
    }

    private void initializeObstacles() {
        Random rand = new Random();
        for (int i = 0; i < obstaclesX.length; i++) {
            obstaclesX[i] = rand.nextInt(3) * 200 + 150;
            obstaclesY[i] = rand.nextInt(300) - 300;
        }
    }

    private void updateGame() {
        if (gameOver) {
            return;
        }

        for (int i = 0; i < obstaclesY.length; i++) {
            obstaclesY[i] += obstacleSpeed;
            if (obstaclesY[i] > getHeight()) {
                obstaclesY[i] = -30;
                obstaclesX[i] = new Random().nextInt(3) * 200 + 150;
            }

            if (new Rectangle(carX, carY, 50, 30).intersects(new Rectangle(obstaclesX[i], obstaclesY[i], 30, 30))) {
                gameOver = true;
                gameTimer.stop();
            }
        }
        gamePanel.repaint();
    }

    private class GamePanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            if (!gameStarted) {
                g.setColor(Color.BLACK);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(Color.WHITE);
                g.setFont(new Font("Arial", Font.BOLD, 30));
                g.drawString("Veicolo Radiocomandato", 230, 180);
                
                g.setColor(Color.GREEN);
                g.fillRect(startButton.x, startButton.y, startButton.width, startButton.height);
                g.setColor(Color.BLACK);
                g.setFont(new Font("Arial", Font.BOLD, 20));
                g.drawString("Avvia Gioco", startButton.x + 50, startButton.y + 32);
                
                g.setColor(Color.RED);
                g.fillRect(exitButton.x, exitButton.y, exitButton.width, exitButton.height);
                g.setColor(Color.BLACK);
                g.drawString("Exit", exitButton.x + 80, exitButton.y + 32);
                return;
            }
            
            if (gameOver) {
                g.setColor(Color.RED);
                g.setFont(new Font("Arial", Font.BOLD, 40));
                g.drawString("GAME OVER", 300, 250);
                
                g.setColor(Color.BLUE);
                g.fillRect(tryAgainButton.x, tryAgainButton.y, tryAgainButton.width, tryAgainButton.height);
                g.setColor(Color.WHITE);
                g.setFont(new Font("Arial", Font.BOLD, 20));
                g.drawString("Try Again", tryAgainButton.x + 50, tryAgainButton.y + 32);
                return;
            }
            
            g.setColor(Color.GRAY);
            g.fillRect(0, 0, getWidth(), getHeight());
            
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 15));
            g.drawString("Comandi: A = Sinistra | D = Destra | J = Velocizza | K = Rallenta", 20, 30);
            
            if (selectedVehicle.equals("Auto")) {
                g.setColor(Color.RED); // Auto in rosso
                g.fillRect(carX, carY, 50, 30);
            } else if (selectedVehicle.equals("Moto")) {
                g.setColor(Color.YELLOW); // Moto in giallo (triangolo)
                int[] xPoints = {carX, carX + 25, carX + 50};
                int[] yPoints = {carY, carY - 40, carY};
                g.fillPolygon(xPoints, yPoints, 3);
            } else if (selectedVehicle.equals("Camion")) {
                g.setColor(new Color(139, 69, 19)); // Camion marrone (quadrato)
                g.fillRect(carX, carY, 70, 40);
            }

            g.setColor(Color.BLACK);
            for (int i = 0; i < obstaclesX.length; i++) {
                g.fillRect(obstaclesX[i], obstaclesY[i], 30, 30);
            }

            for (int i = 0; i < obstaclesX.length; i++) {
                if (Math.abs(obstaclesX[i] - carX) < 60 && obstaclesY[i] > carY - 100) {
                    g.setColor(Color.YELLOW);
                    if (selectedVehicle.equals("Moto")) {
                        g.fillRect(carX + 12, carY, 10, 30);  // Moto with slightly thinner lights
                    } else if (selectedVehicle.equals("Camion")) {
                        g.fillRect(carX - 10, carY, 20, 40);  // Camion with bigger lights
                        g.fillRect(carX + 60, carY, 20, 40);
                    } else {
                        g.fillRect(carX - 10, carY, 5, 30);  // Auto lights
                        g.fillRect(carX + 55, carY, 5, 30);
                    }
                }
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_A && carX > 150) {
            carX -= carSpeed;
        }
        if (e.getKeyCode() == KeyEvent.VK_D && carX < 550) {
            carX += carSpeed;
        }
        if (e.getKeyCode() == KeyEvent.VK_J) {
            obstacleSpeed += 2;
        }
        if (e.getKeyCode() == KeyEvent.VK_K && obstacleSpeed > 2) {
            obstacleSpeed -= 2;
        }
    }

    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}

    @Override
    public void mouseClicked(MouseEvent e) {
        if (!gameStarted) {
            if (startButton.contains(e.getPoint())) {
                // Show vehicle selection
                showVehicleSelection();
            }
            if (exitButton.contains(e.getPoint())) {
                System.exit(0);
            }
        } else if (gameOver && tryAgainButton.contains(e.getPoint())) {
            // Show vehicle selection again before starting the game again
            showVehicleSelectionForRetry();
        }
    }

    private void showVehicleSelection() {
        JFrame selectionFrame = new JFrame("Scegli Veicolo");
        selectionFrame.setSize(400, 300);
        selectionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        selectionFrame.setLocationRelativeTo(this);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        JButton autoButton = new JButton("Auto");
        JButton motoButton = new JButton("Moto");
        JButton camionButton = new JButton("Camion");

        autoButton.addActionListener(e -> {
            selectedVehicle = "Auto";
            showConfirmation(selectionFrame);
        });
        motoButton.addActionListener(e -> {
            selectedVehicle = "Moto";
            showConfirmation(selectionFrame);
        });
        camionButton.addActionListener(e -> {
            selectedVehicle = "Camion";
            showConfirmation(selectionFrame);
        });

        // Change button colors and add hover effects
        autoButton.setBackground(Color.RED);
        autoButton.setForeground(Color.WHITE);
        motoButton.setBackground(Color.YELLOW);
        motoButton.setForeground(Color.BLACK);
        camionButton.setBackground(new Color(139, 69, 19));  // brown
        camionButton.setForeground(Color.WHITE);

        panel.add(autoButton);
        panel.add(motoButton);
        panel.add(camionButton);

        selectionFrame.add(panel);
        selectionFrame.setVisible(true);
    }

    private void showConfirmation(JFrame selectionFrame) {
        // Create a confirmation panel
        JPanel confirmPanel = new JPanel();
        confirmPanel.setLayout(new BoxLayout(confirmPanel, BoxLayout.Y_AXIS));
        
        JLabel confirmationLabel = new JLabel("Hai selezionato: " + selectedVehicle);
        confirmationLabel.setFont(new Font("Arial", Font.BOLD, 20));
        
        JButton startButton = new JButton("Avvia Gioco");
        startButton.setFont(new Font("Arial", Font.BOLD, 20));
        startButton.addActionListener(e -> {
            selectionFrame.dispose();
            startGame(); // Start the game after confirmation
        });

        confirmPanel.add(confirmationLabel);
        confirmPanel.add(startButton);

        // Create a new frame for the confirmation
        JFrame confirmationFrame = new JFrame("Conferma Scelta");
        confirmationFrame.setSize(400, 200);
        confirmationFrame.setLocationRelativeTo(selectionFrame);
        confirmationFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        confirmationFrame.add(confirmPanel);
        confirmationFrame.setVisible(true);
    }

    private void showVehicleSelectionForRetry() {
        JFrame selectionFrame = new JFrame("Scegli Veicolo");
        selectionFrame.setSize(400, 300);
        selectionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        selectionFrame.setLocationRelativeTo(this);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        JButton autoButton = new JButton("Auto");
        JButton motoButton = new JButton("Moto");
        JButton camionButton = new JButton("Camion");

        autoButton.addActionListener(e -> {
            selectedVehicle = "Auto";
            startGame();
            selectionFrame.dispose();
        });
        motoButton.addActionListener(e -> {
            selectedVehicle = "Moto";
            startGame();
            selectionFrame.dispose();
        });
        camionButton.addActionListener(e -> {
            selectedVehicle = "Camion";
            startGame();
            selectionFrame.dispose();
        });

        // Change button colors and add hover effects
        autoButton.setBackground(Color.RED);
        autoButton.setForeground(Color.WHITE);
        motoButton.setBackground(Color.YELLOW);
        motoButton.setForeground(Color.BLACK);
        camionButton.setBackground(new Color(139, 69, 19));  // brown
        camionButton.setForeground(Color.WHITE);

        panel.add(autoButton);
        panel.add(motoButton);
        panel.add(camionButton);

        selectionFrame.add(panel);
        selectionFrame.setVisible(true);
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RadiocomandoGUI().setVisible(true));
    }
}
