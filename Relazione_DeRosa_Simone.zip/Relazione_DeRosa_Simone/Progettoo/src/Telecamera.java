import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// Memento che memorizza il nome dell'ostacolo riconosciuto
class OstacoloMemento {
    private String nomeOstacolo;

    public OstacoloMemento(String nome) {
        this.nomeOstacolo = nome;
    }

    public String getNomeOstacolo() {
        return nomeOstacolo;
    }
}

// Originator: la telecamera che riconosce gli ostacoli e salva i dati
class Telecamera {
    private String ostacoloRiconosciuto;

    public OstacoloMemento salvaOstacolo(String nome) {
        this.ostacoloRiconosciuto = nome;
        return new OstacoloMemento(nome);
    }

    public String riconosciOstacolo(OstacoloMemento memento) {
        return memento.getNomeOstacolo();
    }
}

// Caretaker: archivia i dati sugli ostacoli riconosciuti
class ArchivioOstacoli {
    private Map<String, OstacoloMemento> archivio = new HashMap<>();

    public void aggiungiOstacolo(String id, OstacoloMemento memento) {
        archivio.put(id, memento);
    }

    public OstacoloMemento recuperaOstacolo(String id) {
        return archivio.get(id);
    }
}

