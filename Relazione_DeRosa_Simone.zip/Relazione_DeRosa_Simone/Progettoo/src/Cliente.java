//Ora il cliente per il veicolo per i sensori
/**
 * Classe che rappresenta un cliente del sistema.
 */
public class Cliente {
	    public static void main(String[] args) {
	        // Creazione dei receiver
	        LuceAnteriore luceAnteriore = new LuceAnteriore();
	        LucePosteriore lucePosteriore = new LucePosteriore();
	        LuceSinistra luceSinistra = new LuceSinistra();
	        LuceDestra luceDestra = new LuceDestra();

	        // Creazione dei sensori
	        SensoreCrepuscolare sensoreCrepuscolare = new SensoreCrepuscolare();
	        SensoreProssimita sensoreProssimitaSinistra = new SensoreProssimita();
	        SensoreProssimita sensoreProssimitaDestra = new SensoreProssimita();

	        // Creazione degli osservatori
	        Observer crepuscolare = new OsservatoreCrepuscolare(luceAnteriore, lucePosteriore);
	        ObserverProssimita prossimita = new OsservatoreProssimita(luceSinistra, luceDestra);

	        // Registrazione degli osservatori
	        sensoreCrepuscolare.aggiungiOsservatore(crepuscolare);
	        sensoreProssimitaSinistra.aggiungiOsservatore(prossimita);
	        sensoreProssimitaDestra.aggiungiOsservatore(prossimita);

	        // Simulazione dell'attivazione dei sensori
	        sensoreCrepuscolare.cambiaLuce(1); // Poca luce, accendere luci
	        sensoreCrepuscolare.cambiaLuce(0); // Luce sufficiente, spegnere luci

	        // Simulazione dei sensori di prossimità
	        sensoreProssimitaSinistra.rilevaOstacolo("Sinistra");
	        sensoreProssimitaDestra.rilevaOstacolo("Destra");
	    }
	}