//Il receiver per le marce
public class Marce{
	public void vaiAvanti() {
		System.out.println("Il veicolo parte");
	}
	
	public void vaIndietro() {
		System.out.println("Il veicolo va indietro");
	}
}