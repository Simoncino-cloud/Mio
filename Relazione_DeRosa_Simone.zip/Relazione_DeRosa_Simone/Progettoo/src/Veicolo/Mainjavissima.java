//factory
public class Mainjavissima {
    public static void main(String[] args) {
        try {
            // Uso del factory method per creare veicoli
            VeicoloRC auto = VeicoloFM.creaVeicolo("auto", "A001", "Fiat", 3.6);
            VeicoloRC moto = VeicoloFM.creaVeicolo("moto", "M001", "Suzuki", 4.1);
            VeicoloRC camion = VeicoloFM.creaVeicolo("camion", "C001", "Apecar", 3.3);
            
            // Operazioni sui veicoli
            System.out.println(auto);
            auto.accendi();
            auto.accelera();
            auto.frena();
            auto.spegni();
            
            System.out.println(moto);
            moto.accendi();
            moto.accelera();
            moto.frena();
            moto.spegni();
            
            System.out.println(camion);
            camion.accendi();
            camion.accelera();
            camion.frena();
            camion.spegni();
        } catch (EccezioneVeicolo e) {
            e.printStackTrace();
        }
    }
}

// Classe astratta per il veicolo
abstract class VeicoloRC {
    protected String codice;
    protected String tipoVeicolo;
    protected String marca;
    protected double frequenza;
    
    public VeicoloRC(String codice, String tipoVeicolo, String marca, double frequenza) {
        this.codice = codice;
        this.tipoVeicolo = tipoVeicolo;
        this.marca = marca;
        this.frequenza = frequenza;
    }
    
    // Metodi astratti
    public abstract void frena();
    public abstract void accelera();
    public abstract void accendi();
    public abstract void spegni();
    
    @Override
    public String toString() {
        return "Veicolo{" +
               "codice='" + codice + '\'' +
               ", tipo='" + tipoVeicolo + '\'' +
               ", marca='" + marca + '\'' +
               ", frequenza=" + frequenza +
               '}';
    }
}

// Classe per l'auto
class AutoRC extends VeicoloRC {
    public AutoRC(String codice, String marca, double frequenza) {
        super(codice, "AutoRC", marca, frequenza);
    }

    @Override
    public void accendi() {
        System.out.println("L'auto si accende");
    }

    @Override
    public void accelera() {
        System.out.println("L'auto parte");
    }

    @Override
    public void frena() {
        System.out.println("L'auto si ferma");
    }

    @Override
    public void spegni() {
        System.out.println("L'auto si spegne");
    }
}

// Classe per la moto
class MotoRC extends VeicoloRC {
    public MotoRC(String codice, String marca, double frequenza) {
        super(codice, "MotoRC", marca, frequenza);
    }

    @Override
    public void accendi() {
        System.out.println("La moto si accende");
    }

    @Override
    public void accelera() {
        System.out.println("La moto parte");
    }

    @Override
    public void frena() {
        System.out.println("La moto si ferma");
    }

    @Override
    public void spegni() {
        System.out.println("La moto si spegne");
    }
}

// Classe per il camion
class CamionRC extends VeicoloRC {
    public CamionRC(String codice, String marca, double frequenza) {
        super(codice, "CamionRC", marca, frequenza);
    }

    @Override
    public void accendi() {
        System.out.println("Il camion si accende");
    }

    @Override
    public void accelera() {
        System.out.println("Il camion si muove");
    }

    @Override
    public void frena() {
        System.out.println("Il camion frena");
    }

    @Override
    public void spegni() {
        System.out.println("Il camion si arresta");
    }
}

// Factory per creare i veicoli
class VeicoloFM {
    public static VeicoloRC creaVeicolo(String tipoVeicolo, String codice, String marca, double frequenza) throws EccezioneVeicolo {
        switch (tipoVeicolo.toLowerCase()) {
            case "auto":
                return new AutoRC(codice, marca, frequenza);
            case "moto":
                return new MotoRC(codice, marca, frequenza);
            case "camion":
                return new CamionRC(codice, marca, frequenza);
            default:
                throw new EccezioneVeicolo("Tipo di veicolo non riconosciuto: " + tipoVeicolo);
        }
    }
}

// Classe di eccezione per i veicoli
class EccezioneVeicolo extends Exception {
    public EccezioneVeicolo(String message) {
        super(message);
    }
}
