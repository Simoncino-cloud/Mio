//Implementiamo qui per andare ad accendere le luci in caso di luce scarsa
public class OsservatoreCrepuscolare implements Observer {
    private LuceAnteriore luceAnteriore;
    private LucePosteriore lucePosteriore;

    public OsservatoreCrepuscolare(LuceAnteriore luceAnteriore, LucePosteriore lucePosteriore) {
        this.luceAnteriore = luceAnteriore;
        this.lucePosteriore = lucePosteriore;
    }

    @Override
    public void aggiorna(int luce) {
        if (luce == 1) { // Se c'è poca luce
            luceAnteriore.accendi();
            lucePosteriore.accendi();
        } else {
            luceAnteriore.spegni();
            lucePosteriore.spegni();
        }
    }
}
