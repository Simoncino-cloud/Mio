public class LucePosteriore {
	    public void accendi() {
	        System.out.println("Luce posteriore accesa");
	    }

	    public void spegni() {
	        System.out.println("Luce posteriore spenta");
	    }
	}