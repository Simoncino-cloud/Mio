import java.util.ArrayList;
import java.util.List;
import java.util.List;

//Ora è tempo di implementare la classe Veicolo con le sue funzionalità
//Ponimo questo come Observer che deve cambiare il proprio stato in base ai cambiamenti del Soggetto
public interface Veicolo {
	void aggiorna(int luce);
}



//All'avvistamento di un oggetto in arrivo permette l'accensione delle luci sul radiocomando
interface ObserverProssimita{
	void aggiornaposizione(String direzione);
}


//Rappresenta il soggetto che contiene una lista di osservatori che devono essere notificati
	class SensoreProssimita {
		private List<ObserverProssimita> osservatori = new Arraylist<>();
		private String direzione; //Per l'accenzione della lucina o di destra o sinistra
	
	public void AggiungiOsservatore(ObserverProssimita osservatore) {
		osservatori.add(osservatore);
	}
		
		public void RimuoviOsservatore(ObserverProssimita osservatore) {
			osservatori.remove(osservatore);
		}
		//tutti gli osservatori vengono avvisati e aggiornati
		public void rilevaOstacolo(String direzione) {
	        this.direzione = direzione;
	        notificaOsservatori();
	    }

		//chiama il metodo aggiornaposizione(direzione) per ogni osservatore registrato
		private void notificaOsservatori() {
		    for (int i = 0; i < osservatori.size(); i++) {
		        osservatori.get(i).aggiornaProssimita(direzione);
		    }
		}
	}
	
	
	
	
	

	
	
	
	
	
  


