//Luci del veicolo
public class LuceAnteriore {
	    public void accendi() {
	        System.out.println("Luce anteriore accesa");
	    }

	    public void spegni() {
	        System.out.println("Luce anteriore spenta");
	    }
	}
