//Implementiamo la luce sinistra del Radicomando
public class LuceSinistra {
	    public void accendi() {
	        System.out.println("Luce sinistra accesa");
	    }

	    public void spegni() {
	        System.out.println("Luce sinistra spenta");
	    }
	}
