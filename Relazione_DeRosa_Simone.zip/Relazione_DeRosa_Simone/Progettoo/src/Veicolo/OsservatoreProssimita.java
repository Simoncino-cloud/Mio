//Osservatore in caso di avvicinamento dell'ostacolo al veicolo
public class OsservatoreProssimita implements ObserverProssimita {
	    private LuceSinistra luceSinistra;
	    private LuceDestra luceDestra;

	    public OsservatoreProssimita(LuceSinistra luceSinistra, LuceDestra luceDestra) {
	        this.luceSinistra = luceSinistra;
	        this.luceDestra = luceDestra;
	    }

	    @Override
	    public void aggiornaProssimita(String direzione) {
	        if (direzione.equals("Sinistra")) {
	            luceSinistra.accendi();
	            luceDestra.spegni();
	        } else if (direzione.equals("Destra")) {
	            luceSinistra.spegni();
	            luceDestra.accendi();
	        }
	    }
	}
