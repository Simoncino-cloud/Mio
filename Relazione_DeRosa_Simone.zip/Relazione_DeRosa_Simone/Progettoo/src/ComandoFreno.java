
public class ComandoFreno implements Radiocomando{
	private Motore motore;
	
	public ComandoFreno (Motore motore) {
		this.motore = motore;
	}
	
	@Override
	public void esegui() {
		motore.frena();
	}
}