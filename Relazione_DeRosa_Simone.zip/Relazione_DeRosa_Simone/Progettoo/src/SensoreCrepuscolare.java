//Classe Soggetto che gestisce il sensore che permette l'accensione automatica delle luci

import java.util.ArrayList;
import java.util.List;



public class SensoreCrepuscolare implements Veicolo{
	private List<Observer> observer = new ArrayList<>(); //Per tenere traccia del cambiamento dei Observer
	private int luce; //1 per la condizione di luce bassa, 0 condizione di tanta luce 
	
	
	public void RegistraObserver (Observer osservatore) {
		observer.add(osservatore);
	}
	
	public void RimuoviObserver(Observer osservatore) {
		observer.remove(osservatore);
	}
	
	public void NotificaObservers(){
		for(int i = 0; i < observer.size(); i++) {
			observer.get(i).aggiorna(luce);
		}
		
	}
	
	public void NotificaLuce(Luce luce) {
		this.luce = luce;
		notificaObserver();
	}
	
}
