package Radiocomando;

//Il Receiver dello Sterzo
public class Manubrio{
	public void girasinistra() {
		System.out.println("Manubrio gira a sinistra");
	}
	
	public void giradestra() {
		System.out.println("Manubrio gira a destra");
	}
}
