package Radiocomando;

//Ora gestiamo le marce crendone una che ci permette di partire e andare avanti 
public class PrimaMarcia implements Radiocomando{
	private Marce marce;
	
	public PrimaMarcia (Marce marce) {
		this.marce = marce;
	}
	
	@Override
	public void esegui() {
		marce.vaiAvanti();
}
}