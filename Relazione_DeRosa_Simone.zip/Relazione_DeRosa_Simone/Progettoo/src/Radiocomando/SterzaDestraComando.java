package Radiocomando;

//Qui invece implementiamo il nostro concretecommand
public class SterzaDestraComando implements Radiocomando{
	private Manubrio manubrio;
	
	public SterzaDestraComando(Manubrio manubrio) {
		this.manubrio = manubrio;
	}
	
	@Override
	public void esegui() {
	manubrio.giradestra();
}
}