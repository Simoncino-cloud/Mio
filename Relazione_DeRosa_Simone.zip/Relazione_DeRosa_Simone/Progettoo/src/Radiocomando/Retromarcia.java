package Radiocomando;
//Concrete
//Classe Retromarcia
public class Retromarcia implements Radiocomando{
	private Marce marce;
	
	public Retromarcia(Marce marce) {
		this.marce = marce;
	}
	
	@Override
	public void esegui() {
		marce.vaIndietro();
	}
}
