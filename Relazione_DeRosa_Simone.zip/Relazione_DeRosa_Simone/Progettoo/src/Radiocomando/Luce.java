package Radiocomando;
//Receiver Luce
public class Luce{
	public void accendiSinistra() {
		System.out.println("E' stata accesa la luce Sinistra");
	}
	public void accendiDestra() {
		System.out.println("E' stata accesa la luce Destra");
	}
}
