package Radiocomando;

//Ora il receiver del command per l'acceleratore e per il freno
public class Motore{
	public void accelera() {
		System.out.println("Il veicolo accelera");
	}
	
	public void frena() {
		System.out.println("Il veicolo si ferma");
	}
}