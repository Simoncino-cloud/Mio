//Da qui andiamo a Gestire l'acceleratore e il freno (Concrete)
package Radiocomando;


public class ComandoAcceleratore implements Radiocomando{
	private Motore motore;
	
	public ComandoAcceleratore(Motore motore){
		this.motore = motore;
	}
	@Override
	public void esegui() {
		motore.accelera();
}
}