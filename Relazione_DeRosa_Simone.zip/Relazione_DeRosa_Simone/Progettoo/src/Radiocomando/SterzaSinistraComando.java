package Radiocomando;

//Concretecommand
public class SterzaSinistraComando implements Radiocomando{
	private Manubrio manubrio;
	
	public SterzaSinistraComando(Manubrio manubrio) {
		this.manubrio = manubrio;
	}
	
	@Override
	public void esegui() {
	manubrio.girasinistra();
}
}