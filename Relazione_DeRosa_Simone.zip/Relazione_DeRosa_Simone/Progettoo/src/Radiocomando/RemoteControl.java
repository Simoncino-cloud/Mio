//Il RemoteControl (Invoker)
public class RemoteControl {
  private Radiocomando comando;

  public void setComando(Radiocomando comando) {
      this.comando = comando;
  }

  public void sterzaSinistra() {
      comando.esegui();
  }

  public void sterzaDestra() {
      comando.esegui();
  }

  public void accelera() {
      comando.esegui();
  }

  public void frena() {
      comando.esegui();
  }

  public void selezionaVeicolo() {
      comando.esegui();
  }

  public void vaiAvanti() {
      comando.esegui();
  }

  public void vaIndietro() {
      comando.esegui();
  }
  
  public void accendiSinistra() {
	  comando.esegui();
  }
  
  public void accendiDestra() {
	  comando.esegui();
  }
}
