package Radiocomando;

//Qui per gestire il Radiocomando utilizzeremo il patter Command
public interface Radiocomando {
	void esegui();
}


