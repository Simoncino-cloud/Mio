package Radiocomando;
//(concrete)
public class LampadinaDestra implements Radiocomando{
	private Luce luce;
	
	public LampadinaDestra(Luce luce) {
		this.luce = luce;
	}
	
	@Override
	public void esegui() {
		luce.accendiDestra();
	}
}