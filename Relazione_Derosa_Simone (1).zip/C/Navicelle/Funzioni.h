
#ifndef NAVICELLE_FUNZIONI_H
#define NAVICELLE_FUNZIONI_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//Impostiamo il limite massimo di passi
#define PassiMax 100
#define NAVICELLE 3

//Creiamo una struct per gli spostamenti sulla matrice delle navicelle, e il colore per poterle distinguere
typedef struct {
    int X;
    int Y;
    char colore;
} Navicella ;

//Iniziamo con le funzioni principali per poter costruire il giochino.
void stampa_Mappa(Navicella navicelle[]);
void Posizioni_navicelle(Navicella navicelle[]);
int tuttedistrutte(Navicella navicelle[]);
void aggiornaPosizioni(Navicella navicelle[]);
void Sparo(Navicella navicelle, int scelta);
void Gioca();


#endif //NAVICELLE_FUNZIONI_H
