#include "Funzioni.h"

int main()
{
    Gioca();
    return 0;
}
