#include "Funzioni.h"
//Funzione che permette di farci vedere la mappa
void stampa_Mappa(Navicella navicelle[])
{
    char mappa[8][7] = { ' ' };

//Posiziona le navicelle sulla mappa
    for(int i=0;i<4;i++){
        if(navicelle[i].X >= 0 && navicelle[i].Y <= 7) {
            mappa[navicelle[i].Y][navicelle[i].X] = navicelle[i].colore;
        }
    }

// Stampa la mappa
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 7; j++) {
            printf("%c ", mappa[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

//Inizializziamo le posizioni delle navicelle con l'apposito colore
void Posizioni_navicelle(Navicella navicelle[]) {
    // Inizializziamo la nostra navicella rossa
    navicelle[0].X = 3;
    navicelle[0].Y = 6;
    navicelle[0].colore = 'R';

    // La Navicella gialla
    navicelle[1].X = 0;
    navicelle[1].Y = 0;
    navicelle[1].colore = 'G';

    // La Navicella blu
    navicelle[2].X = 3;
    navicelle[2].Y = 2;
    navicelle[2].colore = 'B';

    // La Navicella verde
    navicelle[3].X = 6;
    navicelle[3].Y = 4;
    navicelle[3].colore = 'V';
}

//Le navicelle cambiano di posizione in base al numero randomico
void aggiornaPosizioni(Navicella navicelle[]) {
    int spostamento;

    // Aggiornamento della navicella gialla
    spostamento = rand() % 100;
    if (spostamento < 60) {
        if (navicelle[1].X < 7 - 1) {
            navicelle[1].X += 1;
        }
    }

    // Aggiornamento della navicella blu
    spostamento = rand() % 100;
    if (spostamento < 70) {
        navicelle[2].X -= 2;
    } else {
        navicelle[2].X -= 1;
    }
    if (navicelle[2].X < 0) navicelle[2].X = 0;

    // Aggiornamento della navicella verde
    spostamento = rand() % 100;
    if (spostamento < 40) {
        navicelle[3].X += 3;
    } else if (spostamento < 70) {
        navicelle[3].X += 2;
    } else {
        navicelle[3].X += 1;
    }
    if (navicelle[3].X > 7 - 1) navicelle[3].X = 7 - 1;
}

//Permette di poter sparare alle navicelle da parte dell'utente
void sparo(Navicella navicelle[], int scelta) {
    if (scelta < 1 || scelta > NAVICELLE) {
        printf("Scelta non valida.\n");
        return;
    }

    // Elimina le navicelle distrutte dalla mappa, sostituendolo con uno spazio
    if(navicelle[scelta].colore != ' ') {
        navicelle[scelta].colore = ' ';
        printf("Hai distrutto la navicella%c!\n", navicelle[scelta].colore);
    } else {
        printf("La navicella e'v stata distrutta. \n");
    }
}

//Funzione che permette di scorrere vendendo se tutte le navicelle sono state eliminate
int tuttedistrutte(Navicella navicelle[]) {
    for (int i = 1; i <= NAVICELLE; i++) {
        if (navicelle[i].colore != ' ') {
            return 0;
        }
    }
    return 1;
}


//Funzione per al gioco di partire
void Gioca()
{
    Navicella navicelle[4];
    int passi = 0;

    srand(time(NULL));
    Posizioni_navicelle(navicelle);

    //Ciclo per poter far avanzare i passi ogni volta
    while(passi < PassiMax && !tuttedistrutte(navicelle)) {
        passi++;
        printf("Passo %d\n", passi);
        stampa_Mappa(navicelle);

        //Sparo da parte dell'utente
        int scelta;
        printf("Scegli a quale nave vuoi sparare (1: Gialla, 2: Blu, 3: Verde):\n");
        scanf("%d", &scelta);
        sparo(navicelle, scelta);
        aggiornaPosizioni(navicelle);
    }

    //Qui possiamo capire nel caso in cui vengano distrutte tutte le navicelle
    if(tuttedistrutte(navicelle))
    {
        printf("CONGRATULAZIONI!!Hai distrutto tutte le navicelle!\n");
    } else {
        printf("Hai perso, non sei riuscito a distruggere le navicelle!");
    }
}
