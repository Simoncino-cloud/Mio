#include "funzioni.h"

int main() {
    int scelta;
    int cont = 0; //Creazioni di variabili per la scelta che l'utente dovrà fare.
    Dizionario elenco[MAX]; //Poniamo appunto il massimo
    printf("****************************************\n");
    printf("*                                      *\n");
    printf("*          Dizionario                  *\n");
    printf("*          Italiano                    *\n");
    printf("*             Piu' di 20.000 parole    *\n");
    printf("*                                      *\n");
    printf("****************************************\n");

    while (scelta != 4) {
        printf("Scegli l'azione da eseguire:\n");
        printf("1. Inserire una parola\n");
        printf("2. Cercare una parola e il corrispettivo significato\n");
        printf("3. Visualizzare la parola con il rispettivo sinonimo\n");
        printf("4. Exit\n");
        scanf("%d%*c", &scelta);

        //in base al numero scelto viene eseguita l'azione
        switch (scelta) {
            case 1:  //Utilizziamo la funzione di inserimento per una nuova parola per il nostro dizionario
                if(Inserimento(elenco, cont));
                printf("\n");
                cont++;
                break;

            case 2:  //utilizziamo la funzione di ricerca per andarla a cercare
                Ricerca(elenco, cont);
                printf("\n");
                break;

            case 3:
                visualizzaSinonimo(elenco, cont);
                printf("\n");
                break;

            case 4:
                printf("Uscita dal programma...");
                break;

            default:
                printf("Questa operazione non è consentita\n");
                break;


        }


    }
    return 0;
}















