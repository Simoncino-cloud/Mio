#include "funzioni.h"


//creiamo una function che ci permetta di inserire nuove parole all'interno del dizionario
int Inserimento(Dizionario elenco[], int cont)
{
    //Utilizzato per capire se il valore di cont, in caso se fosse maggiore delle parole consentite
    printf("\nValore attuale di cont: %d\n", cont);
    if (cont >= MAX) {
        printf("Capacita' massima raggiunta. Non e' possibile aggiungere altre parole.\n");
        return 0;
    }

    // Allocazione dinamica per il campo parola
    elenco[cont].parola = (char *) malloc(30 * sizeof(char));
    if (elenco[cont].parola == NULL)
    {
        printf("Errore di allocazione dinamica per parola.\n");
        free(elenco[cont].parola); // Libera la memoria allocata precedentemente
        return 0;
    }

    // Allocazione dinamica per il campo definizione
    elenco[cont].definizione = (char *) malloc(170 * sizeof(char));
    if (elenco[cont].definizione == NULL) {
        printf("Errore di allocazione dinamica per definizione.\n");
        free(elenco[cont].definizione); // Libera la memoria allocata precedentemente per evitare di riempire
        return 0;
    }

    //Allocazione dinamica per il campo sinonimo
    elenco[cont].sinonimo = (char *) malloc(80 * sizeof(char));
    if(elenco[cont].sinonimo == NULL)
    {
        printf("Errore di allocazione dinamica per sinonimo.\n");
        return 0;
    }

    // Pulizia del buffer
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF);

    //L'utente sceglie la parola da inserire
    printf("Inserire il termine da inserire: ");
    fgets(elenco[cont].parola, 30, stdin);
    elenco[cont].parola[strcspn(elenco[cont].parola, "\n")] = 0; // Rimuovi il '\n'

    //L'utente dopo aver inserito la parola nel dizionario, definisce la parola con un significato
    printf("Inserirne il significato: ");
    fgets(elenco[cont].definizione, 170, stdin);
    elenco[cont].definizione[strcspn(elenco[cont].definizione, "\n")] = 0; // Rimuovi il '\n'

    //E ne definisce i sinonimi
    printf("Inserisci al massimo 5 sinonimi: \n");
    fgets(elenco[cont].sinonimo, 80, stdin);
    elenco[cont].sinonimo[strcspn(elenco[cont].sinonimo, "\n")] = 0;
    elenco[cont].numero_sinonimi = (strlen(elenco[cont].sinonimo) > 0) ? 1 : 0; // Aggiorna il numero di sinonimi

    return 1; // Successo
}
//Funzione che ci permette di visualizzare il sinonimo di una parola da noi inserita nel dizionario
void visualizzaSinonimo(Dizionario elenco[], int cont)
{
    char parola_cercata[30];
    int trovata = 0;

    //chiediamo all'utente di inserira quale parola vuole sapere i sinonimi
    printf("Inserisci la parola di cui vuoi sapere i sinonimi:\n");
    fgets(parola_cercata, sizeof(parola_cercata), stdin);
    parola_cercata[strcspn(parola_cercata, "\n")] = 0;


    for (int i = 0; i < cont; i++) {
        if (strcmp(elenco[i].parola, parola_cercata) == 0) {
            trovata = 1;
            printf("I sinonimi per '%s' sono:\n", elenco[i].parola);

            // Variabile per separare i sinonimi dalla stringa
            char *sinonimo = strtok(elenco[i].sinonimo, " "); //strtok restituisce un puntatore alla parte
            // della stringa che viene separata.
            int j = 1;
            while (sinonimo != NULL) {
                printf(" %d. %s\n", j++, sinonimo);
                sinonimo = strtok(NULL, " ");
            }

            break;
        }
    }
    if (!trovata) {
        printf("Parola non trovata nel dizionario.\n");
    }
}


//funzione che permette all'utente di cercare una parola all'interno del dizionario col sinonimo e significato
void Ricerca(Dizionario elenco[], int cont)
{
    int risultato;    // Variabile per l'indice trovato dalla ricerca binaria
    char parola_ric[30];    // Variabile per la parola da cercare

    printf("Inserire la parola da ricercare: ");
    fgets(parola_ric, sizeof(parola_ric), stdin);
    parola_ric[strcspn(parola_ric, "\n")] = 0;

    risultato = ricerca_ricorsiva(parola_ric, elenco, cont);  // Chiamata alla ricerca binaria

    //se risulta maggiore o uguale a zero restituisce la parola con la seguente definizione
    if (risultato >= 0) {
        printf("%s: %s\n", elenco[risultato].parola, elenco[risultato].definizione);
    } else {
        printf("Parola non trovata\n");
    }
}

//algoritmo di ricerca binaria ricorsiva per poter trovare l'indice dell'elemento che l'utente vuole cercare
int ricerca_ricorsiva(char* chiave, Dizionario elenco[], int n)
{
    int mediano;
    if (n <= 0) {
        return -1;
    }

    mediano = (n - 1) / 2;
    int confronto = strcmp(chiave, elenco[mediano].parola);

    if (confronto == 0) {
        return mediano;
    } else if (confronto < 0) {
        return ricerca_ricorsiva(chiave, elenco, mediano);
    } else {
        int ris = ricerca_ricorsiva(chiave, elenco + mediano + 1, n - mediano - 1);
        return ris == -1 ? -1 : mediano + 1 + ris;
    }
}

