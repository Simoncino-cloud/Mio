#ifndef TRY_ME_FUNZIONI_H
#define TRY_ME_FUNZIONI_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//Poniamo il massimo la capienza massima di parole
#define MAX 1000

//struttura utilizzata per il dizionario
struct dizionario {
    char *parola;
    char *definizione;
    char *sinonimo;
    int   numero_sinonimi;
};
typedef struct dizionario Dizionario;


//definizione dei prototipi delle funzioni
int Inserimento(Dizionario[], int);
void Ricerca(Dizionario elenco[], int cont);
int ricerca_ricorsiva(char*, Dizionario[], int);
void visualizzaSinonimo(Dizionario elenco[], int cont);

#endif //TRY_ME_FUNZIONI_H
